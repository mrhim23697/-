package com.hnust.util;

public class Constants {
    public static final String IMG_PATH = "D:/photos/";
}
